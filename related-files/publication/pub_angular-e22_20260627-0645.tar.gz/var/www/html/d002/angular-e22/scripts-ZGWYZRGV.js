function playSound(a,t){var e=document.createElement("audio"),d="assets/medias/"+a+"/"+t+".mp3";e.setAttribute("src",d),e.play()}
